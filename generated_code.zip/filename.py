from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
import plotly.express as px

app = Flask(__name__)
app.secret_key = "supersecretkey"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file:
            df = pd.read_csv(file)
            fig = px.scatter(df, x="feature_1", y="feature_2")
            return render_template('index.html', figure=fig)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)