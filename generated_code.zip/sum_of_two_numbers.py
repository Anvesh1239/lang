def sum_of_two_numbers(a, b):
  """
  This function returns the sum of two numbers.

  Args:
    a: The first number.
    b: The second number.

  Returns:
    The sum of the two numbers.
  """

  return a + b