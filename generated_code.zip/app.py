from flask import Flask, request

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return "<h1>The Multiplication App</h1>"

@app.route("/multiply", methods=["POST"])
def multiply():
    num1 = request.form.get("num1")
    num2 = request.form.get("num2")
    result = int(num1) * int(num2)
    return f"<h1>The result is {result}</h1>"

if __name__ == "__main__":
    app.run(debug=True)